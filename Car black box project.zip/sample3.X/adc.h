/* 
 * File:   adc.h
 * Author: gowri
 *
 * Created on 31 October, 2024, 10:44 AM
 */
#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */


