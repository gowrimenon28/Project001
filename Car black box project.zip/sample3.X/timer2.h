/* 
 * File:   timer2.h
 * Author: gowri
 *
 * Created on 31 October, 2024, 11:03 AM
 */

#ifndef TIMER_H
#define TIMER_H



void init_timer0(void);
void init_timer2(void);

#endif	/* TIMERS_H */


