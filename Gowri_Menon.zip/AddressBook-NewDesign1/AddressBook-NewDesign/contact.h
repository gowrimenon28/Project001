#ifndef CONTACT_H
#define CONTACT_H

#include <stdio.h>

#define MAX_CONTACTS 100

typedef struct {
    char name[100];
    char phone[20];
    char email[100];
} Contact;

typedef struct {
    Contact contacts[MAX_CONTACTS];
    int contactCount;
    
} AddressBook;

// Function to create a new contact
void createContact(AddressBook *addressBook,FILE *fptr);

// Function to search for a contact by name
void searchContact(const AddressBook *addressBook);

// Function to edit an existing contact
void editContact(AddressBook *addressBook,FILE *fptr);

// Function to delete a contact
void deleteContact(AddressBook *addressBook,FILE *fptr);

// Function to list all contacts
void listContacts(const AddressBook *addressBook);

// Function to load contacts from a file
void populateAddressBook(AddressBook *addressBook);

// Function to save contacts to a file
void saveContactsToFile(const AddressBook *addressBook, FILE *fptr);
void performAction(int choice,AddressBook *addressBook,FILE **fptr);
void displayMenu();
#endif // CONTACT_H