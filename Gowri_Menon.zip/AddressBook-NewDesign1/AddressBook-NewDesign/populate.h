#ifndef POPULATE_H
#define POPULATE_H
#include<stdio.h>

#include "contact.h"

void populateAddressBook(AddressBook* addressBook);
#endif