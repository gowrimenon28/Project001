/*NAME:GOWRI MENON
DATE:19-07-24
PROJECT:ADDRESS_BOOK

OUTPUT:

Address Book Menu:
1. List All Contacts
2. Add New Contact
3. Search For Contact
4. Edit Contact
5. Delete Contact
6. Save Contacts
7. Exit Program */





#include "contact.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void createContact(AddressBook *addressBook,FILE *fptr) {
    if (addressBook->contactCount >= MAX_CONTACTS) {
        printf("Address book is full.\n");
        return;
    }
    printf("Enter name: ");
    fgets(addressBook->contacts[addressBook->contactCount].name, sizeof(addressBook->contacts[addressBook->contactCount].name), stdin);
    addressBook->contacts[addressBook->contactCount].name[strcspn(addressBook->contacts[addressBook->contactCount].name, "\n")] = '\0';

    printf("Enter phone number: ");
    fgets(addressBook->contacts[addressBook->contactCount].phone, sizeof(addressBook->contacts[addressBook->contactCount].phone), stdin);
    addressBook->contacts[addressBook->contactCount].phone[strcspn(addressBook->contacts[addressBook->contactCount].phone, "\n")] = '\0';

    printf("Enter email address: ");
    fgets(addressBook->contacts[addressBook->contactCount].email, sizeof(addressBook->contacts[addressBook->contactCount].email), stdin);
    addressBook->contacts[addressBook->contactCount].email[strcspn(addressBook->contacts[addressBook->contactCount].email, "\n")] = '\0';

    addressBook->contactCount++;
    
    printf("Contact added successfully.\n");

    
    fptr = fopen("address_book.csv", "w");
    if (fptr) {
        saveContactsToFile(addressBook, fptr);
        fclose(fptr);
    } else {
        printf("Failed to open file for writing.\n");
    }
    listContacts(addressBook);  // Display the updated list of contacts


}

void searchContact(const AddressBook *addressBook) {
    char searchQuery[100];
    printf("Enter name to search for: ");
    fgets(searchQuery, sizeof(searchQuery), stdin);
    searchQuery[strcspn(searchQuery, "\n")] = 0; // Remove newline character

    int found = 0;
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strstr(addressBook->contacts[i].name, searchQuery) != NULL) {
            printf("Contact found: Name: %s, Phone: %s, Email: %s\n",
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);
            found = 1;
        }
    }
    if (!found) {
        printf("No contact found with the name '%s'.\n", searchQuery);
    }
}

/*void saveContactsToFile(const AddressBook *addressBook, FILE *fptr) {
    if (fptr == NULL) {
        printf("File pointer is null.\n");
        return;
    }
    for (int i = 0; i < addressBook->contactCount; i++) {
        fprintf(fptr, "%s,%s,%s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }
    printf("Contacts saved to file successfully.\n");
}*/

void editContact(AddressBook *addressBook,FILE *fptr) {
    char searchQuery[100];
    printf("Enter the name of the contact to edit: ");
    fgets(searchQuery, sizeof(searchQuery), stdin);
    searchQuery[strcspn(searchQuery, "\n")] = '\0';

    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].name, searchQuery) == 0) {
            printf("Editing Contact: %s\n", addressBook->contacts[i].name);
            printf("Enter new name (press ENTER to skip): ");
            fgets(addressBook->contacts[i].name, sizeof(addressBook->contacts[i].name), stdin);
            addressBook->contacts[i].name[strcspn(addressBook->contacts[i].name, "\n")] = '\0';

            printf("Enter new phone (press ENTER to skip): ");
            fgets(addressBook->contacts[i].phone, sizeof(addressBook->contacts[i].phone), stdin);
            addressBook->contacts[i].phone[strcspn(addressBook->contacts[i].phone, "\n")] = '\0';

            printf("Enter new email (press ENTER to skip): ");
            fgets(addressBook->contacts[i].email, sizeof(addressBook->contacts[i].email), stdin);
            addressBook->contacts[i].email[strcspn(addressBook->contacts[i].email, "\n")] = '\0';

            printf("Contact updated successfully.\n");
            fptr=fopen("address_book.csv","w");
            
            fptr = fopen("address_book.csv", "w");
            if (fptr) {
                saveContactsToFile(addressBook, fptr);
                fclose(fptr);
            } else {
                printf("Failed to open file for writing.\n");
            }
            listContacts(addressBook);  // Display the updated list of contacts
            return;
        
            
        }
    }
    printf("No contact found with the name '%s'.\n", searchQuery);
}

void deleteContact(AddressBook *addressBook,FILE *fptr) {
    char searchQuery[100];
    printf("Enter the name of the contact to delete: ");
    fgets(searchQuery, sizeof(searchQuery), stdin);
    searchQuery[strcspn(searchQuery, "\n")] = '\0';

    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].name, searchQuery) == 0) {
            for (int j = i; j < addressBook->contactCount - 1; j++) {
                addressBook->contacts[j] = addressBook->contacts[j + 1];
            }
            addressBook->contactCount--;
            
            printf("Contact deleted successfully.\n");
            
            
            fptr = fopen("address_book.csv", "w");
            if (fptr) {
                saveContactsToFile(addressBook, fptr);
                fclose(fptr);
            } else {
                printf("Failed to open file for writing.\n");
            }
            listContacts(addressBook);  // Display the updated list of contacts
            return;
        
            
        
        
        }
    }
    printf("No contact found with the name %s\n",searchQuery);
}

void listContacts(const AddressBook *addressBook) {
    if (addressBook->contactCount == 0) {
        printf("No contacts to display.\n");
        return;
    }

    printf("List of Contacts:\n");
    for (int i = 0; i < addressBook->contactCount; i++) {
        printf("%d. Name: %s, Phone: %s, Email: %s\n",
               i + 1,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }
}
void exitProgram(const AddressBook *addressBook, FILE *fptr) {
    if (fptr != NULL) {
        saveContactsToFile(addressBook, fptr);
        fclose(fptr);
    }
    printf("Exiting the program...\n");
    exit(0);
}
