/*#include<stdio.h>
int main()
{
    char *str ="GOWRI";
    char ch='A';
    //character is capital A
    int a=10;
    float b=20.890,sum;
    /*add the
      integer and
      float values
      and store
      it in the sum variable
    sum=a+b;
    printf("sum of a and b is : ",sum);
    return 0; 
}*/
