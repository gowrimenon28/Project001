/*#include<stdio.h>
int main()
{
    // consider integer and float
    int a = 10;
    float b = 20.0232;
     find the 
       max of
       two
       numbers
    
    if( a > b )
*/
//printf("max of a and b is : ",b);


